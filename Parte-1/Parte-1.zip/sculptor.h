#ifndef SCULPTOR_H
#define SCULPTOR_H

struct Voxel {
    float r, g, b; // Cores
    float a;       // Transpar�ncia
    bool show;     // Inclu�do ou n�o
};

class Sculptor {
private:
  Voxel ***v; // 3D matrix
  int nx,ny,nz; // Dimensions
  float r,g,b,a; // Current drawing color

public:
    // Construtor e Destrutor [cite: 137, 138]
    Sculptor(int _nx, int _ny, int _nz);
    ~Sculptor();

    // M�todos de Controle e Desenho
    void setColor(float r, float g, float b, float a); // Define a cor atual [cite: 139]
    void putVoxel(int x, int y, int z);                // Ativa um voxel [cite: 140]
    void cutVoxel(int x, int y, int z);                // Desativa um voxel [cite: 141]
    void putBox(int x0, int x1, int y0, int y1, int z0, int z1); // Ativa um bloco [cite: 142]
    void cutBox(int x0, int x1, int y0, int y1, int z0, int z1); // Desativa um bloco [cite: 143]
    void putSphere(int xcenter, int ycenter, int zcenter, int radius); // Ativa uma esfera [cite: 144]
    void cutSphere(int xcenter, int ycenter, int zcenter, int radius); // Desativa uma esfera [cite: 145]
    void putEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz); // Ativa um elips�ide [cite: 146]
    void cutEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz); // Desativa um elips�ide [cite: 147]

    // M�todo de Grava��o
    void writeOFF(const char* filename); // Grava a escultura no formato OFF [cite: 147, 151]
};

#endif // SCULPTOR_H
